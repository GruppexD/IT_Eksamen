
--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `bordgruppe`
--
ALTER TABLE `bordgruppe`
  ADD PRIMARY KEY (`B_ID`);

--
-- Indeks for tabel `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`V_ID`);
