
-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `laan`
--
-- Oprettelse: 07. 04 2017 kl. 07:03:15
-- Seneste opdatering: 07. 04 2017 kl. 07:03:15
--

CREATE TABLE `laan` (
  `V_ID` int(11) NOT NULL,
  `B_ID` int(11) NOT NULL,
  `Tid` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
